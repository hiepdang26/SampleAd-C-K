﻿using UnityEngine;
using System;

public class AdsCallback : AndroidJavaProxy
{
    // 🔑 Callback dành riêng cho 1 instance
    public event Action<string> OnAdLoaded;
    public event Action<string, string> OnAdFailed;
    public event Action<string> OnAdOpened;
    public event Action<string> OnAdClosed;
    public event Action<string> OnAdClicked;
    public event Action<string> OnAdDisplayed;
    public event Action<string> OnAdSwipeGestureClicked;
    public event Action<string> OnAdReturnFromClick;

    public AdsCallback() : base("com.blackgems.aar.ads.callback.AdCallbackListener") { }

    // Gọi sang event instance
    void onAdLoaded(string adUnit) => OnAdLoaded?.Invoke(adUnit);
    void onAdFailedToLoad(string adUnit, string error) => OnAdFailed?.Invoke(adUnit, error);
    void onAdOpened(string adUnit) => OnAdOpened?.Invoke(adUnit);
    void onAdClosed(string adUnit) => OnAdClosed?.Invoke(adUnit);
    void onAdClicked(string adUnit) => OnAdClicked?.Invoke(adUnit);
    void onAdDisplayed(string adUnit) => OnAdDisplayed?.Invoke(adUnit);
    void onAdSwipeGestureClicked(string adUnit) => OnAdSwipeGestureClicked?.Invoke(adUnit);
    void onAdReturnFromClick(string adUnit) => OnAdReturnFromClick?.Invoke(adUnit);
}
