﻿using UnityEngine;

public static class AdsBridge
{
    private static AndroidJavaClass bridgeClass;
    private static AndroidJavaObject unityActivity; 

    static AdsBridge()
    {
        bridgeClass = new AndroidJavaClass("com.blackgems.aar.ads.bridge.AdsActivityBridge");
        unityActivity = GetUnityActivity();
    }

    private static AndroidJavaObject GetUnityActivity()
    {
        using (var unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
        {
            return unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
        }
    }

    public static void CreateInstance(string alias, string configJson)
    {
        bridgeClass.CallStatic("createInstance", unityActivity, alias, configJson);
    }

    public static void Clear(string alias)
    {
        bridgeClass.CallStatic("clear", alias);
    }

    public static void PreloadOne(string alias)
    {
        bridgeClass.CallStatic("preloadOneAd", alias, unityActivity);
    }

    public static void PreloadAll(string alias)
    {
        bridgeClass.CallStatic("preloadAllAds", alias, unityActivity);
    }

    public static void ShowSingle(string alias)
    {
        bridgeClass.CallStatic("showSingleAd", unityActivity, alias);
    }

    public static void ShowAll(string alias)
    {
        bridgeClass.CallStatic("showAllAdsAtSameTime", unityActivity, alias);
    }

    public static void ShowSequence(string alias)
    {
        bridgeClass.CallStatic("showAdsInSequence", unityActivity, alias);
    }

    public static void ShowOverlay(string alias, float xDp, float yDp)
    {
        bridgeClass.CallStatic("showOverlayAdWithCoords", alias, unityActivity, xDp, yDp);
    }

    public static void HideOverlay(string alias)
    {
        bridgeClass.CallStatic("hideOverlayAd", alias, unityActivity);
    }

    public static void OpenInspector(string alias)
    {
        bridgeClass.CallStatic("openAdInspector", unityActivity, alias);
    }

    public static void SetCallback(string alias, AdsCallback callback)
    {
        bridgeClass.CallStatic("setUnityCallback", alias, callback);
    }
}
