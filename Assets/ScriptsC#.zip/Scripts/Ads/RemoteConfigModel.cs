using System;
using System.Collections.Generic;

[Serializable]
public class RemoteConfigModel
{
    public List<string> ids;
    public List<long> times;
    public string layout;
    public long totalTime;
}