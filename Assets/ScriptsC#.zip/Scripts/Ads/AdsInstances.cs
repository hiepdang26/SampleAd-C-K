public static class AdsInstances
{
    public static AdsBridgeInstance Ins3;
}
