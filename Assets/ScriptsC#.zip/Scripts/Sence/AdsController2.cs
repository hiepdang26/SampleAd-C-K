﻿using UnityEngine;
using UnityEngine.UI;

public class AdsController2 : MonoBehaviour
{
    private Button countButton;
    private int clickCount = 0;

    void Start()
    {
        // 👉 Vào scene là show overlay luôn (tọa độ x=100dp, y=30dp)
        AdsInstances.Ins3.ShowOverlay(100f, 30f);

        countButton = GameObject.Find("BtnCount")?.GetComponent<Button>();
        if (countButton != null)
        {
            countButton.onClick.AddListener(OnCountButtonClicked);
            UpdateButtonText();
        }
        else
        {
            Debug.LogError("❌ Không tìm thấy button 'BtnCount' trong scene!");
        }
    }

    private void OnCountButtonClicked()
    {
        clickCount++;
        UpdateButtonText();
        Debug.Log($"👉 BtnCount clicked {clickCount} times");
    }

    private void UpdateButtonText()
    {
        var text = countButton.GetComponentInChildren<Text>();
        if (text != null)
        {
            text.text = $"Count: {clickCount}";
        }
    }

    void OnDestroy()
    {
        AdsInstances.Ins3.HideOverlay();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            AdsInstances.Ins3.HideOverlay();
            SceneHistory.LoadLastScene();
        }
    }
}
