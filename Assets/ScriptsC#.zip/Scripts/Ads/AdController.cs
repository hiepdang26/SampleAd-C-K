﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AdsController : MonoBehaviour
{
    private AdsBridgeInstance ins1;
    private AdsBridgeInstance ins2;
    private AdsBridgeInstance ins4;

    private Button btnShowMultipleAds;
    private Button btnShowSequenceAds;
    private Button btnShowSingleAd;
    private Button btnGoToAdsScene;
    private Button btnInspector;

    private void Start()
    {
        //InitIns1();
        //InitIns2();
        InitIns3();
        //InitIns4();
        BindButtons();
    }

    private void InitIns1()
    {
        var config = new RemoteConfigModel
        {
            ids = new List<string> {
                "ca-app-pub-8243023565158105/6052769732",
                "ca-app-pub-8243023565158105/5977861509"
            },
            times = new List<long> { 5000, 5000 },
            layout = "layout_native_language",
            totalTime = 5000
        };
        ins1 = new AdsBridgeInstance(config);

        ins1.OnAdLoaded += (unit) => Debug.Log($"[ins1] ✅ Loaded {unit}");
        ins1.OnAdFailed += (unit, err) => Debug.LogError($"[ins1] ❌ Failed {unit}: {err}");
        ins1.OnAdOpened += (unit) => Debug.Log($"[ins1] 🔓 Opened {unit}");
        ins1.OnAdClosed += (unit) => Debug.Log($"[ins1] ❌ Closed {unit}");
        ins1.OnAdClicked += (unit) => Debug.Log($"[ins1] 👉 Clicked {unit}");
        ins1.OnAdDisplayed += (unit) => Debug.Log($"[ins1] 👀 Displayed {unit}");
        ins1.OnAdSwipeGestureClicked += (unit) => Debug.Log($"[ins1] 👆 SwipeGesture {unit}");
        ins1.OnAdReturnFromClick += (unit) => Debug.Log($"[ins1] ↩️ ReturnFromClick {unit}");

        ins1.PreloadAll();
    }

    private void InitIns2()
    {
        var config = new RemoteConfigModel
        {
            ids = new List<string> { "ca-app-pub-3940256099942544/2247696110" },
            times = new List<long> { 9000 },
            layout = "mrec_single_001",
            totalTime = 5000
        };
        ins2 = new AdsBridgeInstance(config);

        ins2.OnAdLoaded += (unit) => Debug.Log($"[ins2] ✅ Loaded {unit}");
        ins2.OnAdFailed += (unit, err) => Debug.LogError($"[ins2] ❌ Failed {unit}: {err}");
        ins2.OnAdOpened += (unit) => Debug.Log($"[ins2] 🔓 Opened {unit}");
        ins2.OnAdClosed += (unit) => Debug.Log($"[ins2] ❌ Closed {unit}");
        ins2.OnAdClicked += (unit) => Debug.Log($"[ins2] 👉 Clicked {unit}");
        ins2.OnAdDisplayed += (unit) => Debug.Log($"[ins2] 👀 Displayed {unit}");
        ins2.OnAdSwipeGestureClicked += (unit) => Debug.Log($"[ins2] 👆 SwipeGesture {unit}");
        ins2.OnAdReturnFromClick += (unit) => Debug.Log($"[ins2] ↩️ ReturnFromClick {unit}");

        ins2.PreloadAll();
    }

    private void InitIns3()
    {
        var config = new RemoteConfigModel
        {
            ids = new List<string> { "ca-app-pub-8243023565158105/3000344374" },
            times = new List<long> { 10000 },
            layout = "layout_overlay_native_ad",
            totalTime = 10000
        };

        AdsInstances.Ins3 = new AdsBridgeInstance(config);

        AdsInstances.Ins3.OnAdLoaded += (unit) => Debug.Log($"[ins3] ✅ Loaded {unit}");
        AdsInstances.Ins3.OnAdFailed += (unit, err) => Debug.LogError($"[ins3] ❌ Failed {unit}: {err}");
        AdsInstances.Ins3.OnAdOpened += (unit) => Debug.Log($"[ins3] 🔓 Opened {unit}");
        AdsInstances.Ins3.OnAdClosed += (unit) => Debug.Log($"[ins3] ❌ Closed {unit}");
        AdsInstances.Ins3.OnAdClicked += (unit) => Debug.Log($"[ins3] 👉 Clicked {unit}");
        AdsInstances.Ins3.OnAdDisplayed += (unit) => Debug.Log($"[ins3] 👀 Displayed {unit}");
        AdsInstances.Ins3.OnAdSwipeGestureClicked += (unit) => Debug.Log($"[ins3] 👆 SwipeGesture {unit}");
        AdsInstances.Ins3.OnAdReturnFromClick += (unit) => Debug.Log($"[ins3] ↩️ ReturnFromClick {unit}");

        AdsInstances.Ins3.PreloadAll();
    }


    private void InitIns4()
    {
        var config = new RemoteConfigModel
        {
            ids = new List<string> { "ca-app-pub-8243023565158105/6052769732" },
            times = new List<long> { 10000 },
            layout = "mrec_single_001",
            totalTime = 10000
        };
        ins4 = new AdsBridgeInstance(config);

        ins4.OnAdLoaded += (unit) => Debug.Log($"[ins4] ✅ Loaded {unit}");
        ins4.OnAdFailed += (unit, err) => Debug.LogError($"[ins4] ❌ Failed {unit}: {err}");
        ins4.OnAdOpened += (unit) => Debug.Log($"[ins4] 🔓 Opened {unit}");
        ins4.OnAdClosed += (unit) => Debug.Log($"[ins4] ❌ Closed {unit}");
        ins4.OnAdClicked += (unit) => Debug.Log($"[ins4] 👉 Clicked {unit}");
        ins4.OnAdDisplayed += (unit) => Debug.Log($"[ins4] 👀 Displayed {unit}");
        ins4.OnAdSwipeGestureClicked += (unit) => Debug.Log($"[ins4] 👆 SwipeGesture {unit}");
        ins4.OnAdReturnFromClick += (unit) => Debug.Log($"[ins4] ↩️ ReturnFromClick {unit}");

        ins4.PreloadAll();
    }

    private void BindButtons()
    {
        btnShowMultipleAds = GameObject.Find("BtnShowMultipleAds")?.GetComponent<Button>();
        btnShowSequenceAds = GameObject.Find("BtnShowSequence")?.GetComponent<Button>();
        btnShowSingleAd = GameObject.Find("BtnShowSingleAd")?.GetComponent<Button>();
        btnInspector = GameObject.Find("BtnInspector")?.GetComponent<Button>();
        btnGoToAdsScene = GameObject.Find("GoToAdsScene")?.GetComponent<Button>();

        if (btnShowMultipleAds) btnShowMultipleAds.onClick.AddListener(() =>
        {
            ins1.ShowAll();
        });

        if (btnShowSequenceAds) btnShowSequenceAds.onClick.AddListener(() =>
        {
            ins2.ShowSequence();
        });

        if (btnShowSingleAd) btnShowSingleAd.onClick.AddListener(() =>
        {
            ins4.ShowSingle();
        });

        if (btnGoToAdsScene) btnGoToAdsScene.onClick.AddListener(() =>
        {
            SceneHistory.LoadScene("ShowAdsScene");
        });

        if (btnInspector) btnInspector.onClick.AddListener(() =>
        {
            ins1.OpenInspector();
        });
    }

    private void OnDestroy()
    {
        //ins1.Clear();
        //ins2.Clear();
        //AdsInstances.Ins3.Clear();
        //ins4.Clear();
    }
}
