﻿using UnityEngine;
using System;

public class AdsBridgeInstance
{
    private static int counter = 0;
    private string alias;
    private AdsCallback callback; 

    // Expose event ra ngoài
    public event Action<string> OnAdLoaded
    {
        add => callback.OnAdLoaded += value;
        remove => callback.OnAdLoaded -= value;
    }

    public event Action<string, string> OnAdFailed
    {
        add => callback.OnAdFailed += value;
        remove => callback.OnAdFailed -= value;
    }

    public event Action<string> OnAdOpened
    {
        add => callback.OnAdOpened += value;
        remove => callback.OnAdOpened -= value;
    }

    public event Action<string> OnAdClosed
    {
        add => callback.OnAdClosed += value;
        remove => callback.OnAdClosed -= value;
    }

    public event Action<string> OnAdClicked
    {
        add => callback.OnAdClicked += value;
        remove => callback.OnAdClicked -= value;
    }

    public event Action<string> OnAdDisplayed
    {
        add => callback.OnAdDisplayed += value;
        remove => callback.OnAdDisplayed -= value;
    }

    public event Action<string> OnAdSwipeGestureClicked
    {
        add => callback.OnAdSwipeGestureClicked += value;
        remove => callback.OnAdSwipeGestureClicked -= value;
    }

    public event Action<string> OnAdReturnFromClick
    {
        add => callback.OnAdReturnFromClick += value;
        remove => callback.OnAdReturnFromClick -= value;
    }

    public AdsBridgeInstance(RemoteConfigModel config)
    {
        alias = "ins_" + (++counter);

        string jsonConfig = JsonUtility.ToJson(config);
        AdsBridge.CreateInstance(alias, jsonConfig);

        // Tạo callback gắn với alias này
        callback = new AdsCallback();
        AdsBridge.SetCallback(alias, callback);
    }

    // ==== API wrapper ====
    public void PreloadOne() => AdsBridge.PreloadOne(alias);
    public void PreloadAll() => AdsBridge.PreloadAll(alias);
    public void ShowSingle() => AdsBridge.ShowSingle(alias);
    public void ShowAll() => AdsBridge.ShowAll(alias);
    public void ShowSequence() => AdsBridge.ShowSequence(alias);
    public void ShowOverlay(float x, float y) => AdsBridge.ShowOverlay(alias, x, y);
    public void HideOverlay() => AdsBridge.HideOverlay(alias);
    public void OpenInspector() => AdsBridge.OpenInspector(alias);
    public void Clear() => AdsBridge.Clear(alias);
}
